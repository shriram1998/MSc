SELECT * FROM Sailors;
