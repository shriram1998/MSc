SELECT Sailors.A FROM Sailors;
