SELECT SUM(Sailors.A) FROM Sailors, Reserves;
