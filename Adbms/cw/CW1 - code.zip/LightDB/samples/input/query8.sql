SELECT * FROM Sailors ORDER BY Sailors.B;
