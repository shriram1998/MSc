SELECT * FROM Sailors S1, Sailors S2 WHERE S1.A < S2.A;
