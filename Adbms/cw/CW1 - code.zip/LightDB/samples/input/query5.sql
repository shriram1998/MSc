SELECT * FROM Sailors, Reserves WHERE Sailors.A = Reserves.G;
